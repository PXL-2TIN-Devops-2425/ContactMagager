﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ContactManager")]